import random
import pygame, time
from pygame.locals import *

pygame.init()
screen = pygame.display.set_mode((1000, 480))
pygame.display.set_caption('BlackJack')
pygame.mouse.set_visible(0)
Title = pygame.image.load('title.png')
pygame.font.init()
myfont = pygame.font.SysFont('Airiel', 30)
textsurface = myfont.render('Press Enter to Begin', False, (0, 0, 0))
screen.fill((50,200,50))
screen.blit(Title,(100,00))
screen.blit(textsurface,(200,400))
pygame.display.update()

used=[]
hands=[]
Chips=[]
value=[1,2,3,4,5,6,7,8,9,10,10,10,10,1,2,3,4,5,6,7,8,9,10,10,10,10,1,2,3,4,5,6,7,8,9,10,10,10,10,1,2,3,4,5,6,7,8,9,10,10,10,10]
def draw(handNum):
	card=random.randint(1,52)
	if card not in used:
		used.append(card)
		hands[handNum].append(card)
	else:
		draw(handNum)
	return
def printCards(handNum):
	c=0
	while c<handNum:
		if c==0:
			textsurface = myfont.render('Dealer', False, (0, 0, 0))
		else:
			textsurface = myfont.render('Player '+str(c), False, (0, 0, 0))
		screen.blit(textsurface,(200*c,0))
		d=0
		for card in hands[c]:
			if d==0:
				Pic= pygame.image.load('back.jpg')
			else:
				Pic=pygame.image.load( str(card)+'.jpg')
			
			screen.blit(Pic,(200*c+40*d,50))
			d=d+1
		c=c+1
	
	pygame.display.update()
def showCards(handNum):
	c=0
	while c<handNum:
		if c==0:
			textsurface = myfont.render('Dealer', False, (0, 0, 0))
		else:
			textsurface = myfont.render('Player '+str(c), False, (0, 0, 0))
		screen.blit(textsurface,(200*c,0))
		d=0
		for card in hands[c]:
			Pic=pygame.image.load( str(card)+'.jpg')
			
			screen.blit(Pic,(200*c+40*d,50))
			d=d+1
		
		PlayerCount = myfont.render("Point Value:", False, (0, 0, 0))
		PlayerCount1 = myfont.render(str(calcPoints(c)), False, (0, 0, 0))
		screen.blit(PlayerCount,(200*c,120))
		screen.blit(PlayerCount1,(200*c,150))
		c=c+1
		
	
	pygame.display.update()
def printHand(handNum):
	textsurface = myfont.render('Your Cards', False, (0, 0, 0))
	screen.blit(textsurface,(300,200))
	d=0
	for card in hands[handNum]:
		Pic=pygame.image.load( str(card)+' (custom).jpg')
		screen.blit(Pic,(100+80*d,300))
		d=d+1
	pygame.display.update()
def deal():
	x=0
	for y in hands:
		draw(x)
		draw(x)
		x=x+1
	return
def calcPoints(handNum):#caluclates the point value of the hand.
	Points=0
	Ace=False
	if ((1 in hands[handNum]) or (14 in hands[handNum])or (27 in hands[handNum]) or (40 in hands[handNum])):#if an ace is in the hand
		Ace=True
	for x in hands[handNum]:#total points in hand counting aces as 1
		Points=Points+value[x-1]
	if Ace and Points<=11:#Adjust If ace is worth 11
		Points=Points+10
	if Points>21:#Bust
		Points=-1
	#if ((11 in hands[handNum]) or (50 in hands[handNum]))and (Points==21):#Check for BlackJack
		#Points=22
	return Points
q=False
while q==False:
	for event in pygame.event.get():
		if (event.type == KEYDOWN):
			if event.key == pygame.K_RETURN:
				q=True
screen.fill((50,200,50))
PlayerCount = myfont.render('Press 1-4 for the number of players', False, (0, 0, 0))
screen.blit(PlayerCount,(150,300))
pygame.display.update()
Num = 1
q=False
while q==False:
	for event in pygame.event.get():
		if (event.type == KEYDOWN):
			if event.key == pygame.K_1:
				q=True
				Num=1
			if event.key == pygame.K_2:
				q=True
				Num=2
			if event.key == pygame.K_3:
				q=True
				Num=3
			if event.key == pygame.K_4:
				q=True
				Num=4
Num=Num+1 #insert dealer

screen.fill((50,200,50))
while len(hands)< Num:
	hand=[]
	hands.append(hand)
deal()

printCards(Num)
pygame.display.update()
print "Players hand's:"
for x in hands:
	print x[1]
#print "Player 1 has a score of:"
#print calcPoints(1)
y=1
while y<=Num-1:
	#i=raw_input("Player"+str(y)+"'s turn Press Enter to Continue")
	
	screen.fill((50,200,50))
	PlayerCount = myfont.render("Player"+str(y)+"'s turn Press Enter to Continue", False, (0, 0, 0))
	screen.blit(PlayerCount,(150,300))
	printCards(Num)
	pygame.display.update()
	q=False
	while q==False:
		for event in pygame.event.get():
			if (event.type == KEYDOWN):
				if event.key == pygame.K_RETURN:
					q=True
	
	z=0
	#print "Your hand:"
	#for q in hands[y]:
	#	print q
	
	while z==0:
	
		screen.fill((50,200,50))
		printCards(Num)
		printHand(y)
		PlayerCount = myfont.render("Point Value:", False, (0, 0, 0))
		PlayerCount1 = myfont.render(str(calcPoints(y)), False, (0, 0, 0))
		PlayerCount2 = myfont.render("Press H to Hit", False, (0, 0, 0))
		PlayerCount3 = myfont.render("Press S to Stay", False, (0, 0, 0))
		screen.blit(PlayerCount,(800,400))
		screen.blit(PlayerCount1,(800,430))
		screen.blit(PlayerCount2,(800,300))
		screen.blit(PlayerCount3,(800,330))
		pygame.display.update()
		#print "Point value:"
		#print calcPoints(y)
		i='s'
		q=False
		while q==False:
			for event in pygame.event.get():
				if (event.type == KEYDOWN):
					if event.key == pygame.K_h:
						q=True
						i='h'
					if event.key == pygame.K_s:
						q=True
						i='s'
		#i=raw_input("Enter H to hit and S to stay")
		#while i!=('H'or 'S'or 's'or 'h'):
			#i=raw_input("Enter H to hit and S to stay")
		if i==('h'or 'H'):
			draw(y)
			#print "Your hand:"
			#for q in hands[y]:
				#print q
			screen.fill((50,200,50))
			printCards(Num)
			printHand(y)
			if calcPoints(y)==-1:
				#print "BUST!"
				PlayerCount = myfont.render("Bust! Press Enter to Continue", False, (0, 0, 0))
				screen.blit(PlayerCount,(700,400))
				
				pygame.display.update()
				z=1
				q=False
				while q==False:
					for event in pygame.event.get():
						if (event.type == KEYDOWN):
							if event.key == pygame.K_RETURN:
								q=True
	
			else:
				PlayerCount = myfont.render("Point Value:", False, (0, 0, 0))
				PlayerCount1 = myfont.render(str(calcPoints(y)), False, (0, 0, 0))
				screen.blit(PlayerCount,(800,400))
				screen.blit(PlayerCount1,(800,430))
				PlayerCount2 = myfont.render("Press H to Hit", False, (0, 0, 0))
				PlayerCount3 = myfont.render("Press S to Stay", False, (0, 0, 0))
				screen.blit(PlayerCount2,(800,300))
				screen.blit(PlayerCount3,(800,330))
			pygame.display.update()
			
		else:
			z=1
			
	y=y+1
while (calcPoints(0)<17) and (calcPoints(0)!=-1):#Dealer calculations
	draw(0)
	screen.fill((50,200,50))
	printCards(Num)
	PlayerCount = myfont.render("Dealer's turn...", False, (0, 0, 0))
	screen.blit(PlayerCount,(150,300))
	pygame.display.update()
	time.sleep(5)
	#print "dealer hits"
c=0
#for x in hands:
	#if x==hands[0]:
		#print "Dealer's Hand"
	#else:
		#print "Player "+str(c)+"'s hand"
	#print x
	#print "Value:"
	#if calcPoints(c) ==-1:
		#print "Bust!"
	#else:
		#print calcPoints(c)
	#c=c+1

screen.fill((50,200,50))
showCards(Num)
y=0
winners=[0]
while y<=Num-1:
	if calcPoints(y)>calcPoints(winners[0]):
		winners=[y]
	elif calcPoints(y)==calcPoints(winners[0]):
		if winners[0]!=0:
			winners.append(y)
	y=y+1
if len(winners)==1:
	if winners[0]==0:
		PlayerCount = myfont.render("Dealer Wins", False, (0, 0, 0))
		#print "Dealer Wins"
	else:
		#print "Player "+str(winners[0])+" Wins!"
		PlayerCount = myfont.render("Player "+str(winners[0])+" Wins", False, (0, 0, 0))
	
	screen.blit(PlayerCount,(200,300))
	pygame.display.update()
else:
	#print "Tie game Between:"
	
	PlayerCount = myfont.render("Tie Game Between:", False, (0, 0, 0))
	screen.blit(PlayerCount,(200,300))
	t=0
	for q in winners:
		if q==0:
			#print "Dealer"
			PlayerCount = myfont.render("Dealer", False, (0, 0, 0))
			screen.blit(PlayerCount,(200,330+t*30))
		else:
			#print "Player "+str(q)
			PlayerCount = myfont.render("Player "+str(q), False, (0, 0, 0))
			screen.blit(PlayerCount,(200,330+t*30))
		t=t+1
	
	pygame.display.update()
q=False
while q==False:
	for event in pygame.event.get():
		if (event.type == KEYDOWN):
			if event.key == pygame.K_RETURN:
				q=True
	
